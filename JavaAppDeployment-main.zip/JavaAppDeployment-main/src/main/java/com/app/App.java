package main.java.com.app;

public class App {

	public static void main(String[] args) {
		
		System.out.println("This is my first java program after 1.5 years! I missed you java!");

	}

}
